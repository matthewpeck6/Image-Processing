#include <string>
#include <vector>
using std::string;
using namespace std;

struct pixels {
private:
	
	unsigned int blue = 0;
	unsigned int green = 0;
	unsigned int red = 0;
	vector<pixels> Pixel;

public:
	pixels(unsigned int blue, unsigned int green, unsigned int red);
	unsigned int GetBlue();
	unsigned int GetGreen();
	unsigned int GetRed();

};

class extrafile {
private:

	char idLength;
	char colorMapType;
	char dataTypeCode;
	short colorMapOrigin;
	short colorMapLength;
	char colorMapDepth;
	short xOrigin;
	short yOrigin;
	short width;
	short height;
	char bitsPerPixel;
	char imageDescriptor;
	

public:
	
	extrafile(char idLength, char colorMapType, char dataTypeCode,
		short colorMapOrigin, short colorMapLength, char colorMapDepth,
		short xOrigin, short yOrigin, short width, short height,
		char bitsPerPixel, char imageDescriptor);

	char GetIDLength();
	char GetColorMapType();
	char GetDataTypeCode();
	short GetColorMapOrigin();
	short GetColorMapLength();
	char GetColorMapDepth();
	short GetxOrigin();
	short GetyOrigin();
	short GetWidth();
	short GetHeight();
	char GetBitsPerPixel();
	char GetImageDescriptor();

};
