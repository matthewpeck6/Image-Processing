#include "extrafile.h"

extrafile::extrafile(char idLength, char colorMapType, char dataTypeCode,
	short colorMapOrigin, short colorMapLength, char colorMapDepth,
	short xOrigin, short yOrigin, short width, short height,
	char bitsPerPixel, char imageDescriptor) {
	this->idLength = idLength;
	this->colorMapType = colorMapType;
	this->dataTypeCode = dataTypeCode;
	this->colorMapOrigin = colorMapOrigin;
	this->colorMapLength = colorMapLength;
	this->colorMapDepth = colorMapDepth;
	this->xOrigin = xOrigin;
	this->yOrigin = yOrigin;
	this->width = width;
	this->height = height;
	this->bitsPerPixel = bitsPerPixel;
	this->imageDescriptor = imageDescriptor;
}

char extrafile::GetIDLength() {
	return idLength;
}

char extrafile::GetColorMapType() {
	return colorMapType;
}

char extrafile::GetDataTypeCode() {
	return dataTypeCode;
}

short extrafile::GetColorMapOrigin() {
	return colorMapOrigin;
}

short extrafile::GetColorMapLength() {
	return colorMapLength;
}

char extrafile::GetColorMapDepth() {
	return colorMapDepth;
}

short extrafile::GetxOrigin() {
	return xOrigin;
}

short extrafile::GetyOrigin() {
	return yOrigin;
}

short extrafile::GetWidth() {
	return width;
}

short extrafile::GetHeight() {
	return height;
}

char extrafile::GetBitsPerPixel() {
	return bitsPerPixel;
}

char extrafile::GetImageDescriptor() {
	return imageDescriptor;
}




pixels::pixels(unsigned int blue, unsigned int green, unsigned int red) {
	this->blue = blue;
	this->green = green;
	this->red = red;
}

unsigned int pixels::GetBlue() {
	return blue;
}

unsigned int pixels::GetGreen() {
	return green;
}

unsigned int pixels::GetRed() {
	return red;
}





