//#pragma once
#include <iomanip>
#include <iostream>
#include <vector>
#include <string>
#include <ostream>
#include <fstream>
#include <sstream>
#include <istream>
#include "extrafile.h"
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <cmath>
using namespace std;

//Header& headerObject
void ReadFromBinary(string filePath, vector<extrafile>& info, vector<pixels>& Pixel) {
	ifstream inFile(filePath, ios_base::binary);
	cout << "Read: " << filePath << endl;
	if (inFile.is_open()) {
		char idLength;
		char colorMapType;
		char dataTypeCode;
		short colorMapOrigin;
		short colorMapLength;
		char colorMapDepth;
		short xOrigin;
		short yOrigin;
		short width;
		short height;
		char bitsPerPixel;
		char imageDescriptor;


		inFile.read((char*)&idLength, 1);
		inFile.read((char*)&colorMapType, 1);
		inFile.read((char*)&dataTypeCode, sizeof(dataTypeCode));
		inFile.read((char*)&colorMapOrigin, sizeof(colorMapOrigin));
		inFile.read((char*)&colorMapLength, sizeof(colorMapLength));
		inFile.read((char*)&colorMapDepth, sizeof(colorMapDepth));
		inFile.read((char*)&xOrigin, sizeof(xOrigin));
		inFile.read((char*)&yOrigin, sizeof(yOrigin));
		inFile.read((char*)&width, sizeof(width));			//will need width
		inFile.read((char*)&height, sizeof(height));		//will need height
		inFile.read((char*)&bitsPerPixel, sizeof(bitsPerPixel));
		inFile.read((char*)&imageDescriptor, sizeof(imageDescriptor));

		//Count is the size of the image
		unsigned int count = (unsigned int)width * (unsigned int)height;
		//cout << "Count: " << count << endl;

		//should be 12 things pushed back
		extrafile newFormatData(idLength, colorMapType, dataTypeCode, colorMapOrigin, colorMapLength,
		colorMapDepth, xOrigin, yOrigin, width, height, bitsPerPixel, imageDescriptor);
		info.push_back(newFormatData);

		unsigned char red = 0;
		unsigned char green = 0;
		unsigned char blue = 0;
		for (unsigned int i = 0; i < count; i++) {

			inFile.read((char*)&blue, sizeof(blue));

			inFile.read((char*)&green, sizeof(green));

			inFile.read((char*)&red, sizeof(red));

			pixels newData(blue, green, red);
			Pixel.push_back(newData);
		}

		//extrafile newData(name, shipClass, shipLength, shieldCapacity, warpSpeed, numWeapons);
		//info.push_back(newData);
		//info.clear();
	}

}


void WriteFromBinary(string filePath, vector<extrafile>& info, vector<pixels>& Pixel) {
	ofstream outFile(filePath, ios_base::binary);
	cout << endl;
	cout << "Write: " << filePath << endl;
	if (outFile.is_open()) {
		char idLength = info[0].GetIDLength();
		char colorMapType = info[0].GetColorMapType();
		char dataTypeCode = info[0].GetDataTypeCode();
		short colorMapOrigin = info[0].GetColorMapOrigin();
		short colorMapLength = info[0].GetColorMapLength();
		char colorMapDepth = info[0].GetColorMapDepth();
		short xOrigin = info[0].GetxOrigin();
		short yOrigin = info[0].GetyOrigin();
		short width = info[0].GetWidth();
		short height = info[0].GetHeight();
		char bitsPerPixel = info[0].GetBitsPerPixel();
		char imageDescriptor = info[0].GetImageDescriptor();
		

		outFile.write((char*)&idLength, sizeof(idLength));
		outFile.write((char*)&colorMapType, sizeof(colorMapType));
		outFile.write((char*)&dataTypeCode, sizeof(dataTypeCode));
		outFile.write((char*)&colorMapOrigin, sizeof(colorMapOrigin));
		outFile.write((char*)&colorMapLength, sizeof(colorMapLength));
		outFile.write((char*)&colorMapDepth, sizeof(colorMapDepth));
		outFile.write((char*)&xOrigin, sizeof(xOrigin));
		outFile.write((char*)&yOrigin, sizeof(yOrigin));
		outFile.write((char*)&width, sizeof(width));			//will need width
		outFile.write((char*)&height, sizeof(height));		//will need height
		outFile.write((char*)&bitsPerPixel, sizeof(bitsPerPixel));
		outFile.write((char*)&imageDescriptor, sizeof(imageDescriptor));

		unsigned int count = (unsigned int)width * (unsigned int)height;
		//cout << "Count: " << count << endl;
		//extrafile newFormatData(idLength, colorMapType, dataTypeCode, colorMapOrigin, colorMapLength,
		//colorMapDepth, xOrigin, yOrigin, width, height, bitsPerPixel, imageDescriptor);
		//info.push_back(newFormatData);
		//info.clear();

		
		for (unsigned int i = 0; i < count; i++) {

			unsigned char blue = Pixel[i].GetBlue();
			unsigned char green = Pixel[i].GetGreen();
			unsigned char red = Pixel[i].GetRed();

			outFile.write((char*)&blue, sizeof(blue));
			outFile.write((char*)&green, sizeof(green));
			outFile.write((char*)&red, sizeof(red));

			pixels newData(blue, green, red);
			Pixel.push_back(newData);

		}
		//cout << "End of Write Function" << endl;
		//cout << endl;

	}

}

bool TestFromBinary(vector<extrafile>& info, vector<pixels>& Pixel, 
vector<extrafile>& infoExample, vector<pixels>& PixelExample) {
	bool parity = true;
	cout << endl;
	//ReadInBinary and save to info and Pixel Vector
	//Make necessary changes and WriteInBinary since i'm CREATING the picture
	//ReadInBinary and save to infoExample and PixeExample Vector
	//Itierate through Info vectors first and check all values are equal (step 4 in doc)
	//Itierate through Pixel vectors and check all values are equal (step 3 of doc)
	//everything matches, then they are equal; if it doesn't match, than not equal
	//return true or false for parity boolean //return parity;

	char idLength = info[0].GetIDLength();
	char colorMapType = info[0].GetColorMapType();
	char dataTypeCode = info[0].GetDataTypeCode();
	short colorMapOrigin = info[0].GetColorMapOrigin();
	short colorMapLength = info[0].GetColorMapLength();
	char colorMapDepth = info[0].GetColorMapDepth();
	short xOrigin = info[0].GetxOrigin();
	short yOrigin = info[0].GetyOrigin();
	short width = info[0].GetWidth();
	short height = info[0].GetHeight();
	char bitsPerPixel = info[0].GetBitsPerPixel();
	char imageDescriptor = info[0].GetImageDescriptor();

	char idLength2 = infoExample[0].GetIDLength();
	char colorMapType2 = infoExample[0].GetColorMapType();
	char dataTypeCode2 = infoExample[0].GetDataTypeCode();
	short colorMapOrigin2 = infoExample[0].GetColorMapOrigin();
	short colorMapLength2 = infoExample[0].GetColorMapLength();
	char colorMapDepth2 = infoExample[0].GetColorMapDepth();
	short xOrigin2 = infoExample[0].GetxOrigin();
	short yOrigin2 = infoExample[0].GetyOrigin();
	short width2 = infoExample[0].GetWidth();
	short height2 = infoExample[0].GetHeight();
	char bitsPerPixel2 = infoExample[0].GetBitsPerPixel();
	char imageDescriptor2 = infoExample[0].GetImageDescriptor();

	if (idLength != idLength2) {
		parity = false;
	}
	if (colorMapType != colorMapType2) {
		parity = false;
	}
	if (dataTypeCode != dataTypeCode2) {
		parity = false;
	}
	if (colorMapOrigin != colorMapOrigin2) {
		parity = false;
	}
	if (colorMapLength != colorMapLength2) {
		parity = false;
	}
	if (colorMapDepth != colorMapDepth2) {
		parity = false;
	}
	if (xOrigin != xOrigin2) {
		parity = false;
	}
	if (yOrigin != yOrigin2) {
		parity = false;
	}
	if (width != width2) {
		parity = false;
	}
	if (height != height2) {
		parity = false;
	}
	if (bitsPerPixel != bitsPerPixel2) {
		parity = false;
	}
	if (imageDescriptor != imageDescriptor2) {
		parity = false;
	}

	if (parity == true) {
		//cout << "Parity is still true! Header is good." << endl;
	}
	else {
		//cout << "Parity is false. Something went wrong with the Header" << endl;
	}
	unsigned int count = (unsigned int)width * (unsigned int)height;
	//cout << "Count: " << count << endl;


	for (unsigned int i = 0; i < count; i++) {

		unsigned char blue = Pixel[i].GetBlue();
		unsigned char green = Pixel[i].GetGreen();
		unsigned char red = Pixel[i].GetRed();

		unsigned char blue2 = PixelExample[i].GetBlue();
		unsigned char green2 = PixelExample[i].GetGreen();
		unsigned char red2 = PixelExample[i].GetRed();

		if (blue != blue2) {
			parity = false;
		}
		if (green != green2) {
			parity = false;
		}
		if (red != red2) {
			parity = false;
		}

	}
	if (parity == true) {
		//cout << "Parity is still true! YES! Pixel Vector is Good!" << endl;
		cout << "Test Passed!" << endl;
	}
	else {
		//cout << "Parity is false. Something went wrong in Pixel" << endl;
		cout << "Test Failed!" << endl;
	}
	return parity;
}

void ClearFunction(vector<extrafile>& info, vector<pixels>& Pixel,
	vector<extrafile>& infoTwo, vector<pixels>& PixelTwo, 
	vector<extrafile>& infoOutput, vector<pixels>& PixelOutput,
	vector<extrafile>& infoExample, vector<pixels>& PixelExample,
	vector<extrafile>& infoExtra, vector<pixels>& PixelExtra,
	vector<extrafile>& infoExtraOutput, vector<pixels>& PixelExtraOutput) {
	info.clear();
	Pixel.clear();
	infoTwo.clear();
	PixelTwo.clear();
	infoOutput.clear();
	PixelOutput.clear();
	infoExample.clear();
	PixelExample.clear();
	infoExtra.clear();
	PixelExtra.clear();
	infoExtraOutput.clear();
	PixelExtraOutput.clear();
}

void SetupHeader(vector<extrafile>& info, vector<extrafile>& infoOutput) {
	//cout << "Start of Info Header" << endl;
	char idLength = info[0].GetIDLength();
	char colorMapType = info[0].GetColorMapType();
	char dataTypeCode = info[0].GetDataTypeCode();
	short colorMapOrigin = info[0].GetColorMapOrigin();
	short colorMapLength = info[0].GetColorMapLength();
	char colorMapDepth = info[0].GetColorMapDepth();
	short xOrigin = info[0].GetxOrigin();
	short yOrigin = info[0].GetyOrigin();
	short width = info[0].GetWidth();
	short height = info[0].GetHeight();
	char bitsPerPixel = info[0].GetBitsPerPixel();
	char imageDescriptor = info[0].GetImageDescriptor();

	//cout << "Start of Output Header" << endl;
	char idLengthOutput = info[0].GetIDLength();
	char colorMapTypeOutput = info[0].GetColorMapType();
	char dataTypeCodeOutput = info[0].GetDataTypeCode();
	short colorMapOriginOutput = info[0].GetColorMapOrigin();
	short colorMapLengthOutput = info[0].GetColorMapLength();
	char colorMapDepthOutput = info[0].GetColorMapDepth();
	short xOriginOutput = info[0].GetxOrigin();
	short yOriginOutput = info[0].GetyOrigin();
	short widthOutput = info[0].GetWidth();
	short heightOutput = info[0].GetHeight();
	char bitsPerPixelOutput = info[0].GetBitsPerPixel();
	char imageDescriptorOutput = info[0].GetImageDescriptor();
	
	//cout << endl;
	//cout << "Setup Output Header" << endl;

	extrafile newFormatData(idLengthOutput, colorMapTypeOutput, dataTypeCodeOutput,
		colorMapOriginOutput, colorMapLengthOutput, colorMapDepthOutput, xOriginOutput,
		yOriginOutput, widthOutput, heightOutput, bitsPerPixelOutput, imageDescriptorOutput);
	infoOutput.push_back(newFormatData);

	unsigned int count = (unsigned int)width * (unsigned int)height;
	//unsigned int count = 262144;
	//cout <<  "Moving to the Task now" << endl;

}

void Task1Multiply(vector<extrafile>& info, vector<pixels>& Pixel,
	vector<extrafile>& infoTwo, vector<pixels>& PixelTwo, 
	vector<extrafile>& infoOutput, vector<pixels>& PixelOutput ) {

	//cout << "Multiply" << endl;
	//unsigned int count = 262144;
	SetupHeader(info, infoOutput);
	short width = infoOutput[0].GetWidth();
	short height = infoOutput[0].GetHeight();
	//cout << "Width: " << width << endl; //13-14
	//cout << "Height: " << height << endl; //15-16
	unsigned int count = (unsigned int)width * (unsigned int)height;
	//cout << "Count: " << count << endl;

	for (unsigned int i = 0; i < count; i++) {
		unsigned char blue1 = Pixel[i].GetBlue();
		unsigned char green1 = Pixel[i].GetGreen();
		unsigned char red1 = Pixel[i].GetRed();

		unsigned char blue2 = PixelTwo[i].GetBlue();
		unsigned char green2 = PixelTwo[i].GetGreen();
		unsigned char red2 = PixelTwo[i].GetRed();

		float tempBlue = ((float)blue1 * (float)blue2)/255;
		float tempGreen = ((float)green1 * (float)green2) / 255;
		float tempRed = ((float)red1 * (float)red2) / 255;
		tempBlue = tempBlue + 0.5f;
		tempGreen = tempGreen + 0.5f;
		tempRed = tempRed + 0.5f;

		unsigned char blue3 = (unsigned char) tempBlue;
		unsigned char green3 = (unsigned char) tempGreen;
		unsigned char red3 = (unsigned char) tempRed;

		if (blue3 > 255) {
			blue3 = 255;
		} else if (green3 > 255) {
			green3 = 255;
		} else if (red3 > 255) {
			red3 = 255;
		}

		pixels newData(blue3, green3, red3);
		PixelOutput.push_back(newData);
	}

}

void Task2(vector<extrafile>& info, vector<pixels>& Pixel,
	vector<extrafile>& infoTwo, vector<pixels>& PixelTwo,
	vector<extrafile>& infoOutput, vector<pixels>& PixelOutput) {
	
	//cout << "Task 2" << endl;
	//unsigned int count = 262144;
	SetupHeader(info, infoOutput);
	short width = infoOutput[0].GetWidth();
	short height = infoOutput[0].GetHeight();
	//cout << "Width: " << width << endl; //13-14
	//cout << "Height: " << height << endl; //15-16
	unsigned int count = (unsigned int)width * (unsigned int)height;
	//cout << "Count: " << count << endl;

	for (unsigned int i = 0; i < count; i++) {
		unsigned int blue1 = Pixel[i].GetBlue();
		unsigned int green1 = Pixel[i].GetGreen();
		unsigned int red1 = Pixel[i].GetRed();

		unsigned int blue2 = PixelTwo[i].GetBlue();
		unsigned int green2 = PixelTwo[i].GetGreen();
		unsigned int red2 = PixelTwo[i].GetRed();

		int blue = (int)blue1 - (int)blue2;
		int green = (int)green1 - (int)green2;
		int red = (int)red1 - (int)red2;

		if (blue > 255) {
			blue = 255;
		}
		else if (blue < 0) {
			blue = 0;
		}
		if (green > 255) {
			green = 255;
		}
		else if (green < 0) {
			green = 0;
		}
		if (red > 255) {
			red = 255;
		}
		else if (red < 0) {
			red = 0;
		}

		pixels newData((unsigned int)blue, (unsigned int)green, (unsigned int)red);
		PixelOutput.push_back(newData);

	}
	
}

void Task3 (vector<extrafile>& infoOutput, vector<pixels>& PixelOutput,
	vector<extrafile>& infoExtra, vector<pixels>& PixelExtra, 
	vector<extrafile>& infoExtraOutput, vector<pixels>& PixelExtraOutput) {

	//cout << "Task 3" << endl;
	//unsigned int count = 262144;
	SetupHeader(infoOutput, infoExtraOutput);
	short width = infoExtraOutput[0].GetWidth();
	short height = infoExtraOutput[0].GetHeight();
	//cout << "Width: " << width << endl; //13-14
	//cout << "Height: " << height << endl; //15-16
	unsigned int count = (unsigned int)width * (unsigned int)height;
	//cout << "Count: " << count << endl;

	for (unsigned int i = 0; i < count; i++) {
		unsigned int blue1 = PixelOutput[i].GetBlue();
		unsigned int green1 = PixelOutput[i].GetGreen();
		unsigned int red1 = PixelOutput[i].GetRed();

		unsigned int blue2 = PixelExtra[i].GetBlue();
		unsigned int green2 = PixelExtra[i].GetGreen();
		unsigned int red2 = PixelExtra[i].GetRed();

		float blue = ((1 - (1 - ((float) blue1 / 255)) * (1 - ((float) blue2 / 255))) * 255) + 0.5f;
		float green = ((1 - (1 - ((float) green1 / 255)) * (1 - ((float)green2 / 255))) * 255) + 0.5f;
		float red = ((1 - (1 - ((float) red1 / 255)) * (1 - ((float) red2 / 255))) * 255) + 0.5f;

		if (blue > 255) {
			blue = 255;
		}
		else if (green > 255) {
			green = 255;
		}
		else if (red > 255) {
			red = 255;
		}

		pixels newData((int)blue, (int)green, (int)red);
		PixelExtraOutput.push_back(newData);

	}

}

void Task4(vector<extrafile>& infoOutput, vector<pixels>& PixelOutput,
	vector<extrafile>& infoExtra, vector<pixels>& PixelExtra,
	vector<extrafile>& infoExtraOutput, vector<pixels>& PixelExtraOutput) {

	//cout << "Task 4" << endl;
	//unsigned int count = 262144;
	SetupHeader(infoOutput, infoExtraOutput);
	short width = infoExtraOutput[0].GetWidth();
	short height = infoExtraOutput[0].GetHeight();
	//cout << "Width: " << width << endl; //13-14
	//cout << "Height: " << height << endl; //15-16
	unsigned int count = (unsigned int)width * (unsigned int)height;
	//cout << "Count: " << count << endl;

	for (unsigned int i = 0; i < count; i++) {
		unsigned int blue1 = PixelOutput[i].GetBlue();
		unsigned int green1 = PixelOutput[i].GetGreen();
		unsigned int red1 = PixelOutput[i].GetRed();

		unsigned int blue2 = PixelExtra[i].GetBlue();
		unsigned int green2 = PixelExtra[i].GetGreen();
		unsigned int red2 = PixelExtra[i].GetRed();

		int blue = (int)blue1 - (int)blue2;
		int green = (int)green1 - (int)green2;
		int red = (int)red1 - (int)red2;

		if (blue > 255) {
			blue = 255;
		}
		else if (blue < 0) {
			blue = 0;
		}
		if (green > 255) {
			green = 255;
		}
		else if (green < 0) {
			green = 0;
		}
		if (red > 255) {
			red = 255;
		}
		else if (red < 0) {
			red = 0;
		}

		pixels newData((unsigned int)blue, (unsigned int)green, (unsigned int)red);
		PixelExtraOutput.push_back(newData);

	}

}

void Task5(vector<extrafile>& info, vector<pixels>& Pixel,
	vector<extrafile>& infoTwo, vector<pixels>& PixelTwo,
	vector<extrafile>& infoOutput, vector<pixels>& PixelOutput) {

	//cout << "Task 5" << endl;
	//unsigned int count = 262144;
	SetupHeader(info, infoOutput);
	short width = infoOutput[0].GetWidth();
	short height = infoOutput[0].GetHeight();
	//cout << "Width: " << width << endl; //13-14
	//cout << "Height: " << height << endl; //15-16
	unsigned int count = (unsigned int)width * (unsigned int)height;
	//cout << "Count: " << count << endl;

	for (unsigned int i = 0; i < count; i++) {
		unsigned int blue1 = Pixel[i].GetBlue();
		unsigned int green1 = Pixel[i].GetGreen();
		unsigned int red1 = Pixel[i].GetRed();

		unsigned int blue2 = PixelTwo[i].GetBlue();
		unsigned int green2 = PixelTwo[i].GetGreen();
		unsigned int red2 = PixelTwo[i].GetRed();

		float blue = 0.0;
		float green = 0.0;
		float red = 0.0;

		if (((float)blue2 / 255) > 0.5) {
			blue = ((1 - (2 * (1 - ((float)blue1 / 255)) * (1 - ((float)blue2 / 255)))) * 255) + 0.5f;
		}
		else {
			blue = ((2 * ((float)blue1 / 255) * ((float)blue2 / 255)) * 255) + 0.5f;
		}
		if (((float)green2 / 255) > 0.5) {
			green = ((1 - (2 * (1 - ((float)green1 / 255)) * (1 - ((float)green2 / 255)))) * 255) + 0.5f;
		}
		else {
			green = ((2 * ((float)green1 / 255) * ((float)green2 / 255)) * 255) + 0.5f;
		}
		if (((float)red2 / 255) > 0.5) {
			red = ((1 - (2 * (1 - ((float)red1 / 255)) * (1 - ((float)red2 / 255)))) * 255) + 0.5f;
		}
		else {
			red = ((2 * ((float)red1 / 255) * ((float)red2 / 255)) * 255) + 0.5f;
		}

		if (blue > 255) {
			blue = 255;
		}
		else if (green > 255) {
			green = 255;
		}
		else if (red > 255) {
			red = 255;
		}

		pixels newData((unsigned int)blue, (unsigned int)green, (unsigned int)red);
		PixelOutput.push_back(newData);

	}

}

void Task6(vector<extrafile>& info, vector<pixels>& Pixel,
	vector<extrafile>& infoOutput, vector<pixels>& PixelOutput) {

	//cout << "Task 6" << endl;
	//unsigned int count = 262144;
	SetupHeader(info, infoOutput);
	short width = infoOutput[0].GetWidth();
	short height = infoOutput[0].GetHeight();
	//cout << "Width: " << width << endl; //13-14
	//cout << "Height: " << height << endl; //15-16
	unsigned int count = (unsigned int)width * (unsigned int)height;
	//cout << "Count: " << count << endl;

	for (unsigned int i = 0; i < 262144; i++) {
		unsigned int blue1 = Pixel[i].GetBlue();
		unsigned int green1 = Pixel[i].GetGreen();
		unsigned int red1 = Pixel[i].GetRed();

		green1 = green1 + 200;
		if (green1 > 255) {
			green1 = 255;
		}

		pixels newData(blue1, green1, red1);
		PixelOutput.push_back(newData);
	}

}

void Task7(vector<extrafile>& info, vector<pixels>& Pixel,
	vector<extrafile>& infoOutput, vector<pixels>& PixelOutput) {

	//cout << "Task 7" << endl;
	//unsigned int count = 262144;
	SetupHeader(info, infoOutput);
	short width = infoOutput[0].GetWidth();
	short height = infoOutput[0].GetHeight();
	//cout << "Width: " << width << endl; //13-14
	//cout << "Height: " << height << endl; //15-16
	unsigned int count = (unsigned int)width * (unsigned int)height;
	//cout << "Count: " << count << endl;

	for (unsigned int i = 0; i < 262144; i++) {
		unsigned int blue1 = Pixel[i].GetBlue();
		unsigned int green1 = Pixel[i].GetGreen();
		unsigned int red1 = Pixel[i].GetRed();

		red1 = red1 * 4;
		blue1 = 0;
		if (red1 > 255) {
			red1 = 255;
		}

		pixels newData(blue1, green1, red1);
		PixelOutput.push_back(newData);
	}

}

void Task8B(vector<extrafile>& info, vector<pixels>& Pixel,
	vector<extrafile>& infoTwo, vector<pixels>& PixelTwo){
	//cout << "Task 8 Blue" << endl;
	//unsigned int count = 262144;
	SetupHeader(info, infoTwo);
	short width = infoTwo[0].GetWidth();
	short height = infoTwo[0].GetHeight();
	//cout << "Width: " << width << endl; //13-14
	//cout << "Height: " << height << endl; //15-16
	unsigned int count = (unsigned int)width * (unsigned int)height;
	//cout << "Count: " << count << endl;

	for (unsigned int i = 0; i < 262144; i++) {
		unsigned int blue1 = Pixel[i].GetBlue();
		unsigned int green1 = Pixel[i].GetBlue();
		unsigned int red1 = Pixel[i].GetBlue();

		pixels newData(blue1, green1, red1);
		PixelTwo.push_back(newData);
	}
}

void Task8G(vector<extrafile>& info, vector<pixels>& Pixel,
	vector<extrafile>& infoOutput, vector<pixels>& PixelOutput) {
	//cout << "Task 8 Green" << endl;
	//unsigned int count = 262144;
	SetupHeader(info, infoOutput);
	short width = infoOutput[0].GetWidth();
	short height = infoOutput[0].GetHeight();
	//cout << "Width: " << width << endl; //13-14
	//cout << "Height: " << height << endl; //15-16
	unsigned int count = (unsigned int)width * (unsigned int)height;
	//cout << "Count: " << count << endl;

	for (unsigned int i = 0; i < 262144; i++) {
		unsigned int blue1 = Pixel[i].GetGreen();
		unsigned int green1 = Pixel[i].GetGreen();
		unsigned int red1 = Pixel[i].GetGreen();

		pixels newData(blue1, green1, red1);
		PixelOutput.push_back(newData);
	}
}

void Task8R(vector<extrafile>& info, vector<pixels>& Pixel,
	vector<extrafile>& infoExtra, vector<pixels>& PixelExtra) {
	//cout << "Task 8 Red" << endl;
	//unsigned int count = 262144;
	SetupHeader(info, infoExtra);
	short width = infoExtra[0].GetWidth();
	short height = infoExtra[0].GetHeight();
	//cout << "Width: " << width << endl; //13-14
	//cout << "Height: " << height << endl; //15-16
	unsigned int count = (unsigned int)width * (unsigned int)height;
	//cout << "Count: " << count << endl;

	for (unsigned int i = 0; i < 262144; i++) {
		unsigned int blue1 = Pixel[i].GetRed();
		unsigned int green1 = Pixel[i].GetRed();
		unsigned int red1 = Pixel[i].GetRed();

		pixels newData(blue1, green1, red1);
		PixelExtra.push_back(newData);
	}
}

void Task9(vector<extrafile>& info, vector<pixels>& Pixel,
	vector<extrafile>& infoTwo, vector<pixels>& PixelTwo,
	vector<extrafile>& infoExtra, vector<pixels>& PixelExtra,
	vector<extrafile>& infoOutput, vector<pixels>& PixelOutput) {

	//cout << "Task 9" << endl;
	//unsigned int count = 238800;
	SetupHeader(info, infoOutput);
	short width = infoOutput[0].GetWidth();
	short height = infoOutput[0].GetHeight();
	//cout << "Width: " << width << endl; //13-14
	//cout << "Height: " << height << endl; //15-16
	unsigned int count = (unsigned int)width * (unsigned int)height;
	//cout << "Count: " << count << endl;

	for (unsigned int i = 0; i < count; i++) {
		//Pixel had the Blue Data
		unsigned int blue1 = Pixel[i].GetBlue();
		//PixelTwo had the Green Data
		unsigned int green2 = PixelTwo[i].GetGreen();
		//PixelExtra had the Red Data
		unsigned int red3 = PixelExtra[i].GetRed();

		pixels newData(blue1, green2, red3);
		PixelOutput.push_back(newData);
	}
}









int main()
{
	
	//Header headerObject;
	vector <extrafile> info;
	vector <pixels> Pixel;
	vector <extrafile> infoTwo;
	vector <pixels> PixelTwo;
	vector <extrafile> infoOutput;
	vector <pixels> PixelOutput;
	vector <extrafile> infoExample;
	vector <pixels> PixelExample;
	vector <extrafile> infoExtra;
	vector <pixels> PixelExtra;
	vector <extrafile> infoExtraOutput;
	vector <pixels> PixelExtraOutput;

	info.clear();
	Pixel.clear();
	infoTwo.clear();
	PixelTwo.clear();
	infoOutput.clear();
	PixelOutput.clear();
	infoExample.clear();
	PixelExample.clear();
	infoExtra.clear();
	PixelExtra.clear();
	infoExtraOutput.clear();
	PixelExtraOutput.clear();
	
	//The 10 tasks + EC task
	int passed = 0;
	cout << "Doing the tasks in order from 1-9" << endl;
	cout << endl;
	//cout << "Doing the tasks in order from 1-10 + EC" << endl;

		cout << "Task 1" << endl;
		//Read into info and pixel vectors
		ReadFromBinary("input/layer1.tga", info, Pixel);
		//Read into infoTwo and pixelTwo vectors
		ReadFromBinary("input/pattern1.tga", infoTwo, PixelTwo);
		//loop through infoOutput and do task involving pixel and pixelTwo vectors
		Task1Multiply(info, Pixel, infoTwo, PixelTwo, infoOutput, PixelOutput);
		//write out infoOutput
		WriteFromBinary("output/part1.tga", infoOutput, PixelOutput);
		ReadFromBinary("examples/EXAMPLE_part1.tga", infoExample, PixelExample);
		//TestFromBinary(infoOutput, PixelOutput, infoExample, PixelExample);
		if (TestFromBinary(infoOutput, PixelOutput, infoExample, PixelExample) == true) { passed++; }
		ClearFunction(info, Pixel, infoTwo, PixelTwo, infoOutput, PixelOutput,
			infoExample, PixelExample, infoExtra, PixelExtra, infoExtraOutput, PixelExtraOutput);
		//cout << "Cleared the Vectors" << endl;
		cout << "Finished the Task 1 function" << endl;
		cout << endl;
		cout << endl;


		cout << "Task 2" << endl;
		//Read into info and pixel vectors
		ReadFromBinary("input/car.tga", info, Pixel);
		//Read into infoTwo and pixelTwo vectors
		ReadFromBinary("input/layer2.tga", infoTwo, PixelTwo);
		//loop through infoOutput and do task involving pixel and pixelTwo vectors
		Task2(info, Pixel, infoTwo, PixelTwo, infoOutput, PixelOutput);
		//write out infoOutput
		WriteFromBinary("output/part2.tga", infoOutput, PixelOutput);
		ReadFromBinary("examples/EXAMPLE_part2.tga", infoExample, PixelExample);
		//TestFromBinary(infoOutput, PixelOutput, infoExample, PixelExample);
		if (TestFromBinary(infoOutput, PixelOutput, infoExample, PixelExample) == true) { passed++; }
		ClearFunction(info, Pixel, infoTwo, PixelTwo, infoOutput, PixelOutput,
			infoExample, PixelExample, infoExtra, PixelExtra, infoExtraOutput, PixelExtraOutput);
		//cout << "Cleared the Vector" << endl;
		cout << "Finished the Task 2 function" << endl;
		cout << endl;
		cout << endl;


		cout << "Task 3" << endl;
		//Read into info and pixel vectors
		ReadFromBinary("input/layer1.tga", info, Pixel);
		//Read into infoTwo and pixelTwo vectors
		ReadFromBinary("input/pattern2.tga", infoTwo, PixelTwo);
		//loop through infoOutput and do task involving pixel and pixelTwo vectors
		Task1Multiply(info, Pixel, infoTwo, PixelTwo, infoOutput, PixelOutput);
		ReadFromBinary("input/text.tga", infoExtra, PixelExtra); //RedA, GreenA, BlueA
		Task3(infoOutput, PixelOutput, infoExtra, PixelExtra, infoExtraOutput, PixelExtraOutput);
		WriteFromBinary("output/part3.tga", infoExtraOutput, PixelExtraOutput);
		ReadFromBinary("examples/EXAMPLE_part3.tga", infoExample, PixelExample);
		//TestFromBinary(infoExtraOutput, PixelExtraOutput, infoExample, PixelExample);
		if (TestFromBinary(infoExtraOutput, PixelExtraOutput, infoExample, PixelExample) == true) {passed++;}
		ClearFunction(info, Pixel, infoTwo, PixelTwo, infoOutput, PixelOutput,
		infoExample, PixelExample, infoExtra, PixelExtra, infoExtraOutput, PixelExtraOutput);
		//cout << "Cleared the Vectors" << endl;
		cout << "Finished the Task 3 function" << endl;
		cout << endl;
		cout << endl;


		cout << "Task 4" << endl;
		//Read into info and pixel vectors
		ReadFromBinary("input/layer2.tga", info, Pixel);
		//Read into infoTwo and pixelTwo vectors
		ReadFromBinary("input/circles.tga", infoTwo, PixelTwo);
		//loop through infoOutput and do task involving pixel and pixelTwo vectors
		Task1Multiply(info, Pixel, infoTwo, PixelTwo, infoOutput, PixelOutput);
		ReadFromBinary("input/pattern2.tga", infoExtra, PixelExtra); //RedA, GreenA, BlueA
		Task4(infoOutput, PixelOutput, infoExtra, PixelExtra, infoExtraOutput, PixelExtraOutput);
		WriteFromBinary("output/part4.tga", infoExtraOutput, PixelExtraOutput);
		ReadFromBinary("examples/EXAMPLE_part4.tga", infoExample, PixelExample);
		//TestFromBinary(infoExtraOutput, PixelExtraOutput, infoExample, PixelExample);
		if (TestFromBinary(infoExtraOutput, PixelExtraOutput, infoExample, PixelExample) == true) {passed++;}
		ClearFunction(info, Pixel, infoTwo, PixelTwo, infoOutput, PixelOutput,
		infoExample, PixelExample, infoExtra, PixelExtra, infoExtraOutput, PixelExtraOutput);
		//cout << "Cleared the Vectors" << endl;
		cout << "Finished the Task 4 function" << endl;
		cout << endl;
		cout << endl;


		cout << "Task 5" << endl;
		//Read into info and pixel vectors
		ReadFromBinary("input/layer1.tga", info, Pixel);
		//Read into infoTwo and pixelTwo vectors
		ReadFromBinary("input/pattern1.tga", infoTwo, PixelTwo);
		Task5(info, Pixel, infoTwo, PixelTwo, infoOutput, PixelOutput);
		//write out infoOutput
		WriteFromBinary("output/part5.tga", infoOutput, PixelOutput);
		ReadFromBinary("examples/EXAMPLE_part5.tga", infoExample, PixelExample);
		//TestFromBinary(infoOutput, PixelOutput, infoExample, PixelExample);
		if (TestFromBinary(infoOutput, PixelOutput, infoExample, PixelExample) == true) { passed++; }
		ClearFunction(info, Pixel, infoTwo, PixelTwo, infoOutput, PixelOutput,
			infoExample, PixelExample, infoExtra, PixelExtra, infoExtraOutput, PixelExtraOutput);
		//cout << "Cleared the Vectors" << endl;
		cout << "Finished the Task 5 function" << endl;
		cout << endl;
		cout << endl;


		cout << "Task 6" << endl;
		//Read into info and pixel vectors
		ReadFromBinary("input/car.tga", info, Pixel);
		//loop through infoOutput and do task involving pixel and pixelTwo vectors
		Task6(info, Pixel, infoOutput, PixelOutput);
		//write out infoOutput
		WriteFromBinary("output/part6.tga", infoOutput, PixelOutput);
		ReadFromBinary("examples/EXAMPLE_part6.tga", infoExample, PixelExample);
		//TestFromBinary(infoOutput, PixelOutput, infoExample, PixelExample);
		if (TestFromBinary(infoOutput, PixelOutput, infoExample, PixelExample) == true) { passed++; }
		ClearFunction(info, Pixel, infoTwo, PixelTwo, infoOutput, PixelOutput,
			infoExample, PixelExample, infoExtra, PixelExtra, infoExtraOutput, PixelExtraOutput);
		//cout << "Cleared the Vectors" << endl;
		cout << "Finished the Task 6 function" << endl;
		cout << endl;
		cout << endl;


		cout << "Task 7" << endl;
		//Read into info and pixel vectors
		ReadFromBinary("input/car.tga", info, Pixel);
		//loop through infoOutput and do task involving pixel and pixelTwo vectors
		Task7(info, Pixel, infoOutput, PixelOutput);
		//write out infoOutput
		WriteFromBinary("output/part7.tga", infoOutput, PixelOutput);
		ReadFromBinary("examples/EXAMPLE_part7.tga", infoExample, PixelExample);
		//TestFromBinary(infoOutput, PixelOutput, infoExample, PixelExample);
		if (TestFromBinary(infoOutput, PixelOutput, infoExample, PixelExample) == true) { passed++; }
		ClearFunction(info, Pixel, infoTwo, PixelTwo, infoOutput, PixelOutput,
			infoExample, PixelExample, infoExtra, PixelExtra, infoExtraOutput, PixelExtraOutput);
		//cout << "Cleared the Vectors" << endl;
		cout << "Finished the Task 7 function" << endl;
		cout << endl;
		cout << endl;


		cout << "Task 8" << endl;
		int tempPassed = 0;
		ReadFromBinary("input/car.tga", info, Pixel);
		Task8B(info, Pixel, infoTwo, PixelTwo);
		Task8G(info, Pixel, infoOutput, PixelOutput);
		Task8R(info, Pixel, infoExtra, PixelExtra);
		WriteFromBinary("output/part8_b.tga", infoTwo, PixelTwo);
		WriteFromBinary("output/part8_g.tga", infoOutput, PixelOutput);
		WriteFromBinary("output/part8_r.tga", infoExtra, PixelExtra);
		ReadFromBinary("examples/EXAMPLE_part8_b.tga", infoExample, PixelExample);
		if (TestFromBinary(infoTwo, PixelTwo, infoExample, PixelExample) == true) {tempPassed++;}
		infoExample.clear();
		PixelExample.clear();
		ReadFromBinary("examples/EXAMPLE_part8_g.tga", infoExample, PixelExample);
		if (TestFromBinary(infoOutput, PixelOutput, infoExample, PixelExample) == true) {tempPassed++;}
		infoExample.clear();
		PixelExample.clear();
		ReadFromBinary("examples/EXAMPLE_part8_r.tga", infoExample, PixelExample);
		//TestFromBinary(infoExtra, PixelExtra, infoExample, PixelExample);
		if (TestFromBinary(infoExtra, PixelExtra, infoExample, PixelExample) == true) {tempPassed++;}
		if (tempPassed == 3) { 
			passed++;
			cout << "All 3 Colors passed the test" << endl;
		} tempPassed = 0;
		ClearFunction(info, Pixel, infoTwo, PixelTwo, infoOutput, PixelOutput,
		infoExample, PixelExample, infoExtra, PixelExtra, infoExtraOutput, PixelExtraOutput);
		//cout << "Cleared the Vectors" << endl;
		cout << "Finished the Task 8 function" << endl;
		cout << endl;
		cout << endl;


		cout << "Task 9" << endl;
		//Read into info and pixel vectors
		ReadFromBinary("input/layer_blue.tga", info, Pixel);
		ReadFromBinary("input/layer_green.tga", infoTwo, PixelTwo);
		ReadFromBinary("input/layer_red.tga", infoExtra, PixelExtra);
		//loop through infoOutput and do task involving pixel, pixelTwo, and pixelExtra vectors
		Task9(info, Pixel, infoTwo, PixelTwo, infoExtra, PixelExtra, infoOutput, PixelOutput);
		//write out infoOutput
		WriteFromBinary("output/part9.tga", infoOutput, PixelOutput);
		cout << "Finished the Write Function" << endl;
		ReadFromBinary("examples/EXAMPLE_part9.tga", infoExample, PixelExample);
		//TestFromBinary(infoOutput, PixelOutput, infoExample, PixelExample);
		if (TestFromBinary(infoOutput, PixelOutput, infoExample, PixelExample) == true) { passed++; }
		ClearFunction(info, Pixel, infoTwo, PixelTwo, infoOutput, PixelOutput,
			infoExample, PixelExample, infoExtra, PixelExtra, infoExtraOutput, PixelExtraOutput);
		//cout << "Cleared the Vectors" << endl;
		cout << "Finished the Task 9 function" << endl;
		cout << endl;
		cout << endl;


		cout << "Passed: " << passed << endl;
		//cout << "Task 10" << endl;
		//cout << "Task 10 and the EC are still being worked on so for now, it is finished." << endl;		
		cout << "Finish" << endl;
		return 0;

}

/*
	int select;
	cout << "Which Task do you want to Test?" << endl;
	cin >> select;
	cout << endl;
	if (select == 10) {
		return 0;
	} else if (select == 11) {
		//Extra Credit
		return 0;
	} else if (select == 0) {
		return 0;
	}
	else {}
	return 0;
*/
